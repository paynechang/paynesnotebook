//
//  AppDelegate.h
//  RectangleAndPoint
//
//  Created by Payne Chang on 8/26/13.
//  Copyright (c) 2013 Payne Chang. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
