//
//  MyView.m
//  RectangleAndPoint
//
//  Created by Payne Chang on 8/26/13.
//  Copyright (c) 2013 Payne Chang. All rights reserved.
//

#import "MyView.h"

@implementation MyView

- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

/**
 * Draw a point at coordinate (x, y)
 */
- (void)drawPointAtX:(CGFloat)x andY:(CGFloat)y
{
	NSRectFill(NSMakeRect(x, y, 1.0, 1.0));
}

/**
 * drawRect is responsible for drawing the view.
 */
- (void)drawRect:(NSRect)rect
{
	// Clear the view with black color.
	[[NSColor blackColor] set];
	NSRectFill([self bounds]);
	
    // Draw the blue rectangle.
	NSRect myRect = NSMakeRect(20, 10, 200, 100);
	[[NSColor blueColor] set];
	NSRectFill(myRect);
	
	// Draw one white point.
	NSRect myWhitePoint = NSMakeRect(230.0, 120.0, 1.0, 1.0);
	[[NSColor whiteColor] set];
	NSRectFill(myWhitePoint);
	
	// Draw one red point.
	[[NSColor redColor] set];
	[self drawPointAtX:240 andY:130];
}

@end
