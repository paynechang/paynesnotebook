//
//  AppDelegate.m
//  RectangleAndPoint
//
//  Created by Payne Chang on 8/26/13.
//  Copyright (c) 2013 Payne Chang. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
	// Insert code here to initialize your application
}

@end
