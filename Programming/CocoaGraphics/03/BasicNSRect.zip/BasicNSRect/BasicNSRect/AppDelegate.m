//
//  AppDelegate.m
//  BasicNSRect
//
//  Created by Payne Chang on 8/30/13.
//  Copyright (c) 2013 Payne Chang. All rights reserved.
//

#import "AppDelegate.h"

//==============================================================================
@implementation AppDelegate

//==============================================================================
- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
	// Insert code here to initialize your application
}

//==============================================================================
/**
 * Set drawing choice
 */
- (IBAction)setDrawingChoice:(NSButton *)sender
{
	// Set drawing choice for myView
	switch ([sender tag])
	{
		case 0:	// Draw points
			[self.myView setDrawingChoice:@"Points"];
			break;
			
		case 1:	// Draw rectangles
			[self.myView setDrawingChoice:@"Rectangles"];
			break;
			
		case 2:	// Demonstrate offset
			[self.myView setDrawingChoice:@"Offset"];
			break;
			
		case 3:	// Demonstrate intersection
			[self.myView setDrawingChoice:@"Intersection"];
			break;
			
		case 4:	// Demonstrate union
			[self.myView setDrawingChoice:@"Union"];
			break;
			
		case 5:	// Demonstrate inset
			[self.myView setDrawingChoice:@"Inset"];
			break;
			
		default:
			break;
	}
	
	// Redraw myView
	[self.myView setNeedsDisplay:YES];
}

//==============================================================================
@end
