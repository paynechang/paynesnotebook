//
//  AppDelegate.h
//  BasicNSRect
//
//  Created by Payne Chang on 8/30/13.
//  Copyright (c) 2013 Payne Chang. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "MyView.h"

//==============================================================================
@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;
@property (weak) IBOutlet MyView *myView;

- (IBAction)setDrawingChoice:(NSButton *)sender;

//==============================================================================
@end
