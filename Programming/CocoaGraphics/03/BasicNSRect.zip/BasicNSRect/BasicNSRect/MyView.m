//
//  MyView.m
//  BasicNSRect
//
//  Created by Payne Chang on 8/30/13.
//  Copyright (c) 2013 Payne Chang. All rights reserved.
//

#import "MyView.h"

//==============================================================================
@implementation MyView

//==============================================================================
- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

//==============================================================================
/**
 * Functions for drawing a point
 */
- (void)drawPointAtX:(CGFloat)x Y:(CGFloat)y
{
	NSRectFill(NSMakeRect(x, y, 1.0, 1.0));
}

- (void)drawPoint:(NSPoint)aPoint
{
	[self drawPointAtX:aPoint.x Y:aPoint.y];
}

//==============================================================================
/**
 * Draw points
 */
- (void)drawPoints
{
	// Get bounds for x and y coordinates
	CGFloat xBound = [self bounds].size.width;
	CGFloat yBound = [self bounds].size.height;
	
	// Variables for the point and the hue
	NSPoint aPoint = {0, 0};
	CGFloat hue = 0;
	
	// Draw 1000 points
	for ( int i = 0; i < 1000; i++)
	{
		// Set color
		hue = (CGFloat)(arc4random() % 100) / 100.0;
		[[NSColor colorWithCalibratedHue:hue 
							  saturation:1 
							  brightness:1 
								   alpha:1] set];
		
		// Set coordinates
		aPoint.x = arc4random() % (int)xBound;
		aPoint.y = arc4random() % (int)yBound;
		
		// Draw the point
		[self drawPoint:aPoint];		
	}
}

//==============================================================================
/**
 * Draw rectangles
 */
- (void)drawRectangles
{
	// Set size of rectangles
	CGFloat dX = 40;
	CGSize rectSize = {dX, dX};
	
	// Get bounds for x and y coordinates
	CGFloat xBound = [self bounds].size.width - rectSize.width;
	CGFloat yBound = [self bounds].size.height - rectSize.height;
	
	// Variables for drawing
	NSRect aRect = {0, 0, rectSize.width, rectSize.height};
	CGFloat hue = 0;
	int rectCount = 30;
	
	// Draw rectangles. The color changes from colder to warmer.
	for ( int i = 0; i < rectCount; i++)
	{
		// Set color
		hue = (1.0 - (CGFloat)(i) / rectCount) * 0.7;
		[[NSColor colorWithCalibratedHue:hue 
							  saturation:1.0
							  brightness:1.0
								   alpha:1.0] set];
		
		// Set coordinates
		aRect.origin.x = arc4random() % (int)xBound;
		aRect.origin.y = arc4random() % (int)yBound;
		
		// Fill the rectangle
		NSRectFill(aRect);
		
		// Set white color for the frame
		[[NSColor whiteColor] set];
		
		// Draw the frame
		NSFrameRectWithWidth(aRect, 1.0);
	}
}

//==============================================================================
/**
 * Demonstrate offset
 */
- (void)demonstrateOffset
{
	const int rectCount = 2;
	
	// Rectangles
	NSRect rects[rectCount];
	rects[0] = NSMakeRect(50, 30, 200, 100);
	rects[1] = NSOffsetRect(rects[0], 100, 50);
	
	// Colors
	NSColor* colors[rectCount];
	colors[0] = [NSColor redColor];
	colors[1] = [NSColor blueColor];
	
	for ( int i = 0; i < rectCount; i++)
	{
		// Set color
		[colors[i] set];
		
		// Fill the rectangle
		NSRectFill(rects[i]);
		
		// Display rectangle information
		NSLog(@"%@", NSStringFromRect(rects[i])); 
		
		// Set white color for the frame
		[[NSColor whiteColor] set];
		
		// Draw the frame
		NSFrameRectWithWidth(rects[i], 1.0);
	}
}

//==============================================================================
/**
 * Demonstrate intersection
 */
- (void)demonstrateIntersection
{
	const int rectCount = 3;
	
	// Rectangles
	NSRect rects[rectCount];
	rects[0] = NSMakeRect(50, 30, 200, 100);
	rects[1] = NSOffsetRect(rects[0], 100, 50);
	rects[2] = NSIntersectionRect(rects[0], rects[1]);
	
	// Colors
	NSColor* colors[rectCount];
	colors[0] = [NSColor redColor];
	colors[1] = [NSColor blueColor];
	colors[2] = [NSColor greenColor];
	
	for ( int i = 0; i < rectCount; i++)
	{
		// Set color
		[colors[i] set];
		
		// Fill the rectangle
		NSRectFill(rects[i]);
		
		// Set white color for the frame
		[[NSColor whiteColor] set];
		
		// Draw the frame
		NSFrameRectWithWidth(rects[i], 1.0);
	}
}

//==============================================================================
/**
 * Demonstrate union
 */
- (void)demonstrateUnion
{
	const int rectCount = 3;
	
	// Rectangles
	NSRect rects[rectCount];
	rects[1] = NSMakeRect(50, 30, 200, 100);
	rects[2] = NSOffsetRect(rects[1], 100, 50);
	rects[0] = NSUnionRect(rects[1], rects[2]);
	
	// Colors
	NSColor* colors[rectCount];
	colors[1] = [NSColor redColor];
	colors[2] = [NSColor blueColor];
	colors[0] = [NSColor greenColor];
	
	for ( int i = 0; i < rectCount; i++)
	{
		// Set color
		[colors[i] set];
		
		// Fill the rectangle
		NSRectFill(rects[i]);
		
		// Set white color for the frame
		[[NSColor whiteColor] set];
		
		// Draw the frame
		NSFrameRectWithWidth(rects[i], 1.0);
	}
}

//==============================================================================
/**
 * Demonstrate inset
 */
- (void)demonstrateInset
{
	const int rectCount = 2;
	
	// Rectangles
	NSRect rects[rectCount];
	rects[0] = NSMakeRect(50, 30, 200, 100);
	rects[1] = NSInsetRect(rects[0], 20, 10);
	
	// Colors
	NSColor* colors[rectCount];
	colors[0] = [NSColor redColor];
	colors[1] = [NSColor greenColor];
	
	for ( int i = 0; i < rectCount; i++)
	{
		// Set color
		[colors[i] set];
		
		// Fill the rectangle
		NSRectFill(rects[i]);
		
		// Set white color for the frame
		[[NSColor whiteColor] set];
		
		// Draw the frame
		NSFrameRectWithWidth(rects[i], 1.0);
	}
}

//==============================================================================
/**
 * The drawing function
 */
- (void)drawRect:(NSRect)viewRect
{
    // Clear the background
	[[NSColor clearColor] set];
	NSRectFill([self bounds]);
	
	if ([self.drawingChoice isEqualToString:@"Points"])
	{	// Draw points
		[self drawPoints];
	}
	else if ([self.drawingChoice isEqualToString:@"Rectangles"])
	{	// Draw rectangles
		[self drawRectangles];		
	}
	else if ([self.drawingChoice isEqualToString:@"Offset"])
	{	// Demonstrate offset
		[self demonstrateOffset];		
	}
	else if ([self.drawingChoice isEqualToString:@"Intersection"])
	{	// Demonstrate intersection
		[self demonstrateIntersection];		
	}
	else if ([self.drawingChoice isEqualToString:@"Union"])
	{	// Demonstrate union
		[self demonstrateUnion];		
	}
	else if ([self.drawingChoice isEqualToString:@"Inset"])
	{	// Demonstrate inset
		[self demonstrateInset];		
	}
}

@end
//==============================================================================
