//
//  MyView.h
//  BasicNSBezierPathLine
//
//  Created by Payne Chang on 8/29/13.
//  Copyright (c) 2013 Payne Chang. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//==============================================================================
@interface MyView : NSView

@property (nonatomic) NSColor *lineColor;	// Line color
@property CGFloat lineWidth;				// Line width
@property NSInteger dashStyleIndex;			// Dash style index
@property CGFloat dashPhase;				// Dash phase
@property NSLineCapStyle lineCapStyle;		// Line cape style
@property CGPoint startPoint;				// Start point
@property CGPoint endPoint;					// End point

// Set the flag for drawing something interesting
@property BOOL isDrawSomethingInteresting;

@end

//==============================================================================
