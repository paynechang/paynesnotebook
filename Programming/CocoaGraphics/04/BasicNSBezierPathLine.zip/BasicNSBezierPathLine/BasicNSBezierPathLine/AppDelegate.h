//
//  AppDelegate.h
//  BasicNSBezierPathLine
//
//  Created by Payne Chang on 8/29/13.
//  Copyright (c) 2013 Payne Chang. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "MyView.h"

//==============================================================================
@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@property (weak, nonatomic) IBOutlet MyView *myView;

@property (weak, nonatomic) IBOutlet NSColorWell *lineColorWell;

@property (weak, nonatomic) IBOutlet NSTextField *lineWidthText;
@property (weak, nonatomic) IBOutlet NSSlider *lineWidthSlider;

@property (weak, nonatomic) IBOutlet NSTextField *dashPhaseText;
@property (weak, nonatomic) IBOutlet NSSlider *dashPhaseSlider;

@property (weak, nonatomic) IBOutlet NSTextField *startPointXText;
@property (weak, nonatomic) IBOutlet NSSlider *startPointXSlider;

@property (weak, nonatomic) IBOutlet NSTextField *startPointYText;
@property (weak, nonatomic) IBOutlet NSSlider *startPointYSlider;

@property (weak, nonatomic) IBOutlet NSTextField *endPointXText;
@property (weak, nonatomic) IBOutlet NSSlider *endPointXSlider;

@property (weak, nonatomic) IBOutlet NSTextField *endPointYText;
@property (weak, nonatomic) IBOutlet NSSlider *endPointYSlider;

- (IBAction)setLineColor:(NSColorWell *)sender;
- (IBAction)setLineWidth:(NSSlider *)sender;
- (IBAction)setDashStyle:(NSMatrix *)sender;
- (IBAction)setDashPhase:(NSSlider *)sender;
- (IBAction)setCapStyle:(NSMatrix *)sender;
- (IBAction)setPointXY:(NSSlider *)sender;
- (IBAction)giveMeSomethingInteresting:(NSButton *)sender;

@end
//==============================================================================
