//
//  AppDelegate.m
//  BasicNSBezierPathLine
//
//  Created by Payne Chang on 8/29/13.
//  Copyright (c) 2013 Payne Chang. All rights reserved.
//

#import "AppDelegate.h"

//==============================================================================
@implementation AppDelegate

//==============================================================================
- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
	// Line color
	self.myView.lineColor = [self.lineColorWell color];
	
	// Line width
	self.myView.lineWidth = [self.lineWidthSlider doubleValue];
	[self.lineWidthText setStringValue:[NSString stringWithFormat:@"%.1f", self.myView.lineWidth]];

	// Dash style
	self.myView.dashStyleIndex = 0;
	self.myView.dashPhase = [self.dashPhaseSlider doubleValue];
	[self.dashPhaseText setStringValue:[NSString stringWithFormat:@"Phase = %.0f", self.myView.dashPhase]];
	
	// Start point
	self.myView.startPoint = NSMakePoint([self.startPointXSlider doubleValue], [self.startPointYSlider doubleValue]);
	[self.startPointXText setStringValue:[NSString stringWithFormat:@"X = %.0f", [self.startPointXSlider doubleValue]]];
	[self.startPointYText setStringValue:[NSString stringWithFormat:@"Y = %.0f", [self.startPointYSlider doubleValue]]];
	
	// End point
	self.myView.endPoint = NSMakePoint([self.endPointXSlider doubleValue], [self.endPointYSlider doubleValue]);
	[self.endPointXText setStringValue:[NSString stringWithFormat:@"X = %.0f", [self.endPointXSlider doubleValue]]];
	[self.endPointYText setStringValue:[NSString stringWithFormat:@"Y = %.0f", [self.endPointYSlider doubleValue]]];
	
	// Update the view
	[self.myView setNeedsDisplay:YES];
}

//==============================================================================
- (IBAction)setLineColor:(NSColorWell *)sender
{
	self.myView.lineColor = [sender color];
	[self.myView setNeedsDisplay:YES];
}

//==============================================================================
- (IBAction)setLineWidth:(id)sender
{
	self.myView.lineWidth = [sender doubleValue];
	[self.lineWidthText setStringValue:[NSString stringWithFormat:@"%.1f", self.myView.lineWidth]];
	[self.myView setNeedsDisplay:YES];
}

//==============================================================================
- (IBAction)setDashStyle:(NSMatrix *)sender
{
	[self.myView setDashStyleIndex:[sender selectedTag]];	
	[self.myView setNeedsDisplay:YES];
}

//==============================================================================
- (IBAction)setDashPhase:(NSSlider *)sender
{
	self.myView.dashPhase = [sender doubleValue];
	[self.dashPhaseText setStringValue:[NSString stringWithFormat:@"Phase = %.0f", [sender doubleValue]]];
	[self.myView setNeedsDisplay:YES];
}

//==============================================================================
- (IBAction)setCapStyle:(NSMatrix *)sender
{
	switch ([sender selectedTag]) {
		case 0:
			self.myView.lineCapStyle = NSButtLineCapStyle;
			break;
			
		case 1:
			self.myView.lineCapStyle = NSSquareLineCapStyle;
			break;
			
		case 2:
			self.myView.lineCapStyle = NSRoundLineCapStyle;
			break;
			
		default:
			break;
	}
	
	[self.myView setNeedsDisplay:YES];
}

//==============================================================================
- (IBAction)setPointXY:(NSSlider *)sender
{
	switch (sender.tag)
	{
		case 0:	// Start point X coordinate
			self.myView.startPoint = NSMakePoint([sender doubleValue], self.myView.startPoint.y);
			[self.startPointXText setStringValue:[NSString stringWithFormat:@"X = %.0f", [sender doubleValue]]];					
			break;
			
		case 1:	// Start point Y coordinate
			self.myView.startPoint = NSMakePoint(self.myView.startPoint.x, [sender doubleValue]);
			[self.startPointYText setStringValue:[NSString stringWithFormat:@"Y = %.0f", [sender doubleValue]]];					
			break;
			
		case 2:	// End point X coordinate
			self.myView.endPoint = NSMakePoint([sender doubleValue], self.myView.endPoint.y);
			[self.endPointXText setStringValue:[NSString stringWithFormat:@"X = %.0f", [sender doubleValue]]];					
			break;
			
		case 3:	// End point Y coordinate
			self.myView.endPoint = NSMakePoint(self.myView.endPoint.x, [sender doubleValue]);
			[self.endPointYText setStringValue:[NSString stringWithFormat:@"Y = %.0f", [sender doubleValue]]];					
			break;
			
		default:
			break;
	}
	
	[self.myView setNeedsDisplay:YES];
}

//==============================================================================
- (IBAction)giveMeSomethingInteresting:(NSButton *)sender
{
	self.myView.isDrawSomethingInteresting = YES;
	[self.myView setNeedsDisplay:YES];
}

//==============================================================================
@end
