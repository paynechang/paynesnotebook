//
//  MyView.m
//  BasicNSBezierPathLine
//
//  Created by Payne Chang on 8/29/13.
//  Copyright (c) 2013 Payne Chang. All rights reserved.
//

#import "MyView.h"

//==============================================================================
// Private
@interface MyView()
{
	// For four dash patterns we will define later.
	NSInteger dashSegmentCount[4];	
	CGFloat dashSegmentLength[4][4];
}

@end

//==============================================================================
// Implementation
@implementation MyView

//==============================================================================
// Define four dash patterns
- (void)defineDashStyle
{
	// Solid
	dashSegmentCount[0] = 0;
	
	// Dash pattern: 40 - 40
	dashSegmentCount[1] = 2;
	dashSegmentLength[1][0] = 40;
	dashSegmentLength[1][1] = 40;
	
	// Dash pattern: 80 - 40
	dashSegmentCount[2] = 2;
	dashSegmentLength[2][0] = 80;
	dashSegmentLength[2][1] = 40;
	
	// Dash pattern: 40 - 20 - 10 - 20
	dashSegmentCount[3] = 4;
	dashSegmentLength[3][0] = 40;
	dashSegmentLength[3][1] = 20;
	dashSegmentLength[3][2] = 10;
	dashSegmentLength[3][3] = 20;
}

//==============================================================================
// Initialization of MyView
- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
	
    if (self)
	{
        [self defineDashStyle];
		self.isDrawSomethingInteresting = NO;
    }
    
    return self;
}

//==============================================================================
// The drawing function
- (void)drawRect:(NSRect)viewRect
{
    // Clear the background with white color.
	[[NSColor whiteColor] set];
	NSRectFill([self bounds]);
	
	// If isDrawSomethingInteresting is set to YES, let's draw someting
	// interesting and skip the remaining code in this function.
	if (self.isDrawSomethingInteresting)
	{
		[self drawSomethingInteresting];
		self.isDrawSomethingInteresting = NO;
		return;
	}
	
	// Create NSBezierPath object, set attributes, and make a stroke
	NSBezierPath *path = [NSBezierPath bezierPath];
	[self.lineColor set];						// Set line color
	[path setLineWidth:self.lineWidth];			// Set line width
	[path setLineDash:dashSegmentLength[self.dashStyleIndex]	// Set line dash
				count:dashSegmentCount[self.dashStyleIndex]
				phase:self.dashPhase];
	[path setLineCapStyle:self.lineCapStyle];	// Set line cap
	[path moveToPoint:self.startPoint];			// Move to the start point
	[path lineToPoint:self.endPoint];			// Create a line to the end point
	[path stroke];								// Stroke
	
	// Draw the black center line
	[[NSColor blackColor] set];
	[path setLineWidth:1.0];
	[path stroke];
}

//==============================================================================
// Draw something interesting.
- (void)drawSomethingInteresting
{
	// Draw three line paths
	for (int i = 0; i < 3; i++)
	{
		// Create the NSBezierPath object
		NSBezierPath *path = [NSBezierPath bezierPath];	
		
		// Move to the start point
		[path moveToPoint:NSMakePoint(arc4random() % (int)[self bounds].size.width, 
									  arc4random() % (int)[self bounds].size.height)];				
		
		// Set line color
		[[NSColor colorWithCalibratedHue:(CGFloat)(arc4random()%100)/100.0
							  saturation:1.0
							  brightness:1.0
								   alpha:1.0] set];
		
		// Set line width
		[path setLineWidth:(CGFloat)(arc4random()%100)/100.0 * 9 + 1];	
		
		// Set line dash
		NSInteger index = arc4random() % 4;
		[path setLineDash:dashSegmentLength[index]
					count:dashSegmentCount[index]
					phase:arc4random() % 100];
		
		// Set line cap
		index = arc4random() % 3;
		
		switch (index)
		{
			case 0:
				[path setLineCapStyle:NSButtLineCapStyle];
				break;
				
			case 1:
				[path setLineCapStyle:NSSquareLineCapStyle];
				break;
				
			case 2:
				[path setLineCapStyle:NSRoundLineCapStyle];
				break;
		}
		
		
		// Make 10 line segments
		for (int i = 0; i < 10; i++)
		{
			// Create a line to the end point
			[path lineToPoint:NSMakePoint(arc4random() % (int)[self bounds].size.width, 
										  arc4random() % (int)[self bounds].size.height)];
		}
		
		// Stroke
		[path stroke];
	}
}

@end	// @implementation MyView
//==============================================================================
