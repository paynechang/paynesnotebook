//
//  MyView.m
//  Arc
//
//  Created by Payne Chang on 9/13/13.
//  Copyright (c) 2013 Payne Chang. All rights reserved.
//

#import "MyView.h"

@implementation MyView

- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

- (void)drawRect:(NSRect)viewRect
{
	// Arc
    NSBezierPath *arcPath = [NSBezierPath bezierPath];
	[arcPath setLineWidth:3];
	NSPoint center = NSMakePoint(100, 100);

	[arcPath moveToPoint:center];
	[arcPath appendBezierPathWithArcWithCenter:center 
										radius:50 
									startAngle:0 
									  endAngle:270];
	
	[[NSColor whiteColor] set];
	[arcPath fill];
	
	[[NSColor blueColor] set];
	[arcPath stroke];
	
	// Rectangle
	NSRect rect = {200, 50, 200, 100};
	NSBezierPath *rectPath = [NSBezierPath bezierPathWithRect:rect];
	[rectPath setLineWidth:3];
	
	[[NSColor whiteColor] set];
	[rectPath fill];
	
	[[NSColor blueColor] set];
	[rectPath stroke];
}

@end
