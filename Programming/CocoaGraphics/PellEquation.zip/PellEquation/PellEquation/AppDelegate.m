//
//  AppDelegate.m
//  PellEquation
//
//  Created by Payne Chang on 9/19/13.
//  Copyright (c) 2013 Payne Chang. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
	// Insert code here to initialize your application
}

@end
