//
//  main.m
//  PellEquation
//
//  Created by Payne Chang on 9/19/13.
//  Copyright (c) 2013 Payne Chang. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
	return NSApplicationMain(argc, (const char **)argv);
}
