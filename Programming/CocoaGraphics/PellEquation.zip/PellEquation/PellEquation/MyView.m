//
//  MyView.m
//  PellEquation
//
//  Created by Payne Chang on 9/19/13.
//  Copyright (c) 2013 Payne Chang. All rights reserved.
//

// http://www.offtonic.com/blog/?p=29

#import "MyView.h"


//==============================================================================
@interface MyView()
{
    NSMutableAttributedString *pellString;
}

@end

//==============================================================================
@implementation MyView

- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
	
    if (self)
	{
        pellString = [[NSMutableAttributedString alloc] initWithString:@"x2 – Dy2 = N"];
		
		// NSFontDescriptor
		NSFontDescriptor *eqDesc = [NSFontDescriptor fontDescriptorWithFontAttributes:nil];
		NSFontSymbolicTraits eqMask = NSFontOldStyleSerifsClass;
		eqDesc = [eqDesc fontDescriptorWithSymbolicTraits:eqMask];
		
		// actually get the matching descriptors; the only attribute I used was NSFontTraitsAttribute
		NSArray *descriptors = [eqDesc matchingFontDescriptorsWithMandatoryKeys:
								[NSSet setWithObject:NSFontTraitsAttribute]];
		
		// here I am stupidly making fallback plans in case Times New Roman isn't available
		// the for loop goes through each descriptor and adds it to the Times or Times New Roman arrays
		// depending on whether the font name contains those strings
		NSMutableArray *timesDescriptors = [NSMutableArray array];
		NSMutableArray *timesNewRomanDescriptors = [NSMutableArray array];
		
		for (id desc in descriptors)
		{
			NSString *descName = [[desc fontAttributes] objectForKey:NSFontNameAttribute];
			
			if ([descName rangeOfString:@"Times"
								options:NSCaseInsensitiveSearch].location != NSNotFound)
			{
				[timesDescriptors addObject:desc];
				
				if ([descName rangeOfString:@"TimesNewRoman"
									options:NSCaseInsensitiveSearch].location != NSNotFound)
				{
					[timesNewRomanDescriptors addObject:desc];
				}
			}
		}
		
		// if Times New Roman is not available, use Times instead
		if ([timesNewRomanDescriptors count] == 0) timesNewRomanDescriptors = timesDescriptors;
		
		// if that's not available either, use some other serif font
		if ([timesNewRomanDescriptors count] == 0) timesNewRomanDescriptors = [NSMutableArray arrayWithArray:descriptors];		NSMutableArray *normalFonts = [NSMutableArray array];

		NSMutableArray *italicFonts = [NSMutableArray array];
		for (id desc in timesNewRomanDescriptors)
		{
			NSString *descName = [[desc fontAttributes] objectForKey:NSFontNameAttribute];
			// check that the font isn't bold
			if ([descName rangeOfString:@"Bold"
								options:NSCaseInsensitiveSearch].location == NSNotFound)
			{
				// now check if it's not italic; then it's a normal font
				if ([descName rangeOfString:@"Italic"
									options:NSCaseInsensitiveSearch].location == NSNotFound)
				{
					[normalFonts addObject:desc];
				}
				else
				{
					// if it is italic, it's an italic font
					[italicFonts addObject:desc];
				}
			}
		}		
		
		// some fonts, which I'll get into later; just assume they're defined for now
		NSFont *constants; // size 24
		NSFont *exponents; // size 18
		NSFont *variables; // size 24
		
		// if somehow there are no serif fonts to use, just go with the user font, which is probably Lucida Grande
		if ([normalFonts count] == 0)
		{
			constants = [NSFont userFontOfSize:24];
			exponents = [NSFont userFontOfSize:18];
		}
		else
		{
			// take the first normal serif font, since there's no better ranking system
			constants = [NSFont fontWithDescriptor:[normalFonts objectAtIndex:0]
											  size:24];
			exponents = [NSFont fontWithDescriptor:[normalFonts objectAtIndex:0]
											  size:18];
		}
		
		// if there are no serif italic fonts, try to find *any* italic font
		// it probably won't match the normal one but at this point, the user needs to install some fonts
		if ([italicFonts count] == 0)
		{
			NSFontSymbolicTraits italics = NSFontItalicTrait;
			NSFontDescriptor *italicDesc = [NSFontDescriptor fontDescriptorWithFontAttributes:nil];
			italicDesc = [italicDesc fontDescriptorWithSymbolicTraits:italics];
			italicDesc = [italicDesc matchingFontDescriptorWithMandatoryKeys:
						  [NSSet setWithObject:NSFontTraitsAttribute]];
			
			if (italicDesc)
			{
				variables = [NSFont fontWithDescriptor:italicDesc
												  size:24];
			}
			else
			{
				// if no italic fonts at all can be found, at least the program won't crash
				variables = [NSFont userFontOfSize:24];
			}
		}
		else
		{
			// again, this is the first italic serif font.  Hopefully it matches the normal font
			variables = [NSFont fontWithDescriptor:[italicFonts objectAtIndex:0]
											  size:24];
		}
		
		// actually style this string
        [pellString addAttribute:NSFontAttributeName
                           value:variables
                           range:NSMakeRange(0, 1)]; // x
        [pellString addAttribute:NSSuperscriptAttributeName
                           value:[NSNumber numberWithInt:1]
                           range:NSMakeRange(1, 1)];
        [pellString addAttribute:NSFontAttributeName
                           value:exponents
                           range:NSMakeRange(1, 1)]; // 2
        [pellString addAttribute:NSFontAttributeName
                           value:constants
                           range:NSMakeRange(2, 3)]; // ' – '
        [pellString addAttribute:NSFontAttributeName
                           value:variables
                           range:NSMakeRange(5, 2)]; // Dy
        [pellString addAttribute:NSSuperscriptAttributeName
                           value:[NSNumber numberWithInt:1]
                           range:NSMakeRange(7, 1)];
        [pellString addAttribute:NSFontAttributeName
                           value:exponents
                           range:NSMakeRange(7, 1)]; // 2
        [pellString addAttribute:NSFontAttributeName
                           value:constants
                           range:NSMakeRange(8, 3)]; // ' = '
        [pellString addAttribute:NSFontAttributeName
                           value:variables
                           range:NSMakeRange(11, 1)]; // N
	}
    
    return self;
}

//==============================================================================
- (void)drawRect:(NSRect)dirtyRect
{
	// get the size of the string
    NSSize psSize = [pellString size];
	
	// get the rect of the view
    NSRect frame = [self bounds];
	
	// calculate the lower left corner of where the string should be drawn
    NSPoint p;
	
    p.x = (frame.size.width - psSize.width)/2;
	
    p.y = (frame.size.height - psSize.height)/2;
	
	// actually draw the string
    [pellString drawAtPoint:p];
	
	// Draw the rect
	NSRect theRect = {p.x, p.y, psSize.width, psSize.height};
	[[NSColor redColor] set];
	NSFrameRect(theRect);
}

//==============================================================================
@end
