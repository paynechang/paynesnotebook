//
//  MyView.m
//  ExploreNSColor
//
//  Created by Payne Chang on 8/28/13.
//  Copyright (c) 2013 Payne Chang. All rights reserved.
//

#import "MyView.h"

@implementation MyView

- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

- (void)drawRect:(NSRect)rect
{
    // Clear the view.
	[[NSColor clearColor] set];		// Clear the background with black color
	//[[NSColor whiteColor] set];	// Clear the background with white color
	NSRectFill([self bounds]);
	
	int colorCount = 20;	// For hue
	int otherCount = 10;	// For saturation, brightness, or alpha
	CGFloat dy = 30;		// Increment in y direction
	CGFloat dx = 5;			// Width of one color bar
	
	// The first column
	// Test saturation
	NSRect rect0 = NSMakeRect(20, 10, dx, 20);
	NSRect rect1 = rect0;
	
	for ( int j = 0; j <= otherCount; j++)
	{
		rect1 = NSOffsetRect(rect1, 0, dy);
		NSRect rect2 = rect1;
		
		for ( int i = 0; i <= colorCount; i++)
		{
			[[NSColor colorWithCalibratedHue:(CGFloat)i/colorCount 
								  saturation:(CGFloat)j/otherCount 
								  brightness:1 
									   alpha:1] set];
			rect2 = NSOffsetRect(rect2, dx, 0);
			NSRectFill(rect2);
		}
	}
	
	// The second column
	// Test brightness
	rect0 = NSOffsetRect(rect0, 130, 0);
	rect1 = rect0;
	
	for ( int j = 0; j <= otherCount; j++)
	{
		rect1 = NSOffsetRect(rect1, 0, dy);
		NSRect rect2 = rect1;
		
		for ( int i = 0; i <= colorCount; i++)
		{
			[[NSColor colorWithCalibratedHue:(CGFloat)i/colorCount 
								  saturation:1
								  brightness:(CGFloat)j/otherCount 
									   alpha:1] set];
			rect2 = NSOffsetRect(rect2, dx, 0);
			NSRectFill(rect2);
		}
	}
	
	// The third column
	// Test alpha
	rect0 = NSOffsetRect(rect0, 130, 0);
	rect1 = rect0;
	
	for ( int j = 0; j <= otherCount; j++)
	{
		rect1 = NSOffsetRect(rect1, 0, dy);
		NSRect rect2 = rect1;
		
		for ( int i = 0; i <= colorCount; i++)
		{
			[[NSColor colorWithCalibratedHue:(CGFloat)i/colorCount 
								  saturation:1
								  brightness:1
									   alpha:(CGFloat)j/otherCount] set];
			rect2 = NSOffsetRect(rect2, dx, 0);
			NSRectFill(rect2);
		}
	}
	
	// The fourth column
	// Test brightness and alpha
	rect0 = NSOffsetRect(rect0, 130, 0);
	rect1 = rect0;
	
	for ( int j = 0; j <= otherCount; j++)
	{
		rect1 = NSOffsetRect(rect1, 0, dy);
		NSRect rect2 = rect1;
		
		for ( int i = 0; i <= colorCount; i++)
		{
			[[NSColor colorWithCalibratedHue:(CGFloat)i/colorCount 
								  saturation:1
								  brightness:(CGFloat)j/otherCount
									   alpha:(CGFloat)j/otherCount] set];
			rect2 = NSOffsetRect(rect2, dx, 0);
			NSRectFill(rect2);
		}
	}
}

@end
