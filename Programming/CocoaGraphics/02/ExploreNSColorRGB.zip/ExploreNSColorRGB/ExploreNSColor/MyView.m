//
//  MyView.m
//  ExploreNSColor
//
//  Created by Payne Chang on 8/28/13.
//  Copyright (c) 2013 Payne Chang. All rights reserved.
//

#import "MyView.h"

@implementation MyView

- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

- (void)drawRect:(NSRect)rect
{
    // Clear the view.
	[[NSColor clearColor] set];		// Clear the background with black color
	NSRectFill([self bounds]);
	
	int colorCount = 20;	// For red
	int otherCount = 10;	// For green and blue
	CGFloat dy = 30;		// Increment in y direction
	CGFloat dx = 1;			// Width of one color rect
	
	NSRect rect0 = NSMakeRect(20, 10, dx, 20);
	NSRect rect1, rect2;
	
	for ( int b = 0; b <= otherCount; b++)	// Increment blue
	{
		rect0 = NSOffsetRect(rect0, dx * colorCount + 10, 0);
		rect1 = rect0;
		
		for ( int g = 0; g <= otherCount; g++)	// Increment green
		{
			rect1 = NSOffsetRect(rect1, 0, dy);
			rect2 = rect1;
			
			for ( int r = 0; r <= colorCount; r++)	// increment red
			{
				// Set color
				[[NSColor colorWithCalibratedRed:(CGFloat)r/colorCount 
										   green:(CGFloat)g/otherCount 
											blue:(CGFloat)b/otherCount 
										   alpha:1] set];
				// Shift the rect
				rect2 = NSOffsetRect(rect2, dx, 0);
				
				// Fill the rect with the color
				NSRectFill(rect2);
			}
		}
		
	}
}

@end
